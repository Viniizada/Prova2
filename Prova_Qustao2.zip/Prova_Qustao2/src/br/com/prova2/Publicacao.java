package br.com.prova2;

public interface Publicacao {

    void buscarTitulo (String titulo);
    void visualizarDetalhes();

}
